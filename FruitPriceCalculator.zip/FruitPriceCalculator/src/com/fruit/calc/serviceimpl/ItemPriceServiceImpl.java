package com.fruit.calc.serviceimpl;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Optional;
import java.util.stream.Stream;

import com.fruit.calc.model.FruitPrice;
import com.fruit.calc.service.ItemPriceService;
import com.fruit.calc.service.PriceListService;

public class ItemPriceServiceImpl implements ItemPriceService {

	private PriceListService priceList;
	
	public ItemPriceServiceImpl(PriceListService aPriceList) {
		this.priceList = aPriceList;
	}

	@Override
	public Optional<BigDecimal> priceItem(String itemId, int quantity) {
		Stream<FruitPrice> offers = priceList.getPricesForItem(itemId).stream()
				.sorted((x,y)-> x.getPricePerUnit().compareTo(y.getPricePerUnit())) ;

		int quantityRemaining = quantity;
		BigDecimal totalPrice = new BigDecimal(0);

		Iterator<FruitPrice> it = offers.iterator();

		while(quantityRemaining > 0 && it.hasNext())
		{
			FruitPrice offer = it.next();
			if(quantityRemaining >= offer.getQuantity())
			{
				int nbOfOffersToTake = quantityRemaining / offer.getQuantity();
				BigDecimal priceOfThisQuantity = offer.getPrice().multiply(new BigDecimal(nbOfOffersToTake));
				totalPrice = totalPrice.add(priceOfThisQuantity);
				quantityRemaining -= nbOfOffersToTake * offer.getQuantity(); 
			}
		}
		if(quantityRemaining == 0){
			return Optional.of(totalPrice);
		}else{
			return Optional.empty();
		}
	}
	
}