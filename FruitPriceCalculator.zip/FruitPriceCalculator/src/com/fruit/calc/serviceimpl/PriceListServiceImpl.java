package com.fruit.calc.serviceimpl;

import java.util.Collection;
import java.util.stream.Collectors;
import com.fruit.calc.model.FruitPrice;
import com.fruit.calc.service.PriceListService;

public class PriceListServiceImpl implements PriceListService
{
	private Collection<FruitPrice> fruitPrices;
	
	public PriceListServiceImpl(Collection<FruitPrice> staticData)
	{
		fruitPrices = staticData;
	}


	public Collection<FruitPrice> getPricesForItem(String itemId)
	{
		return fruitPrices.stream().filter(fruitPrices -> fruitPrices.getItemId().equals(itemId)).collect(Collectors.toList());
	}
}
