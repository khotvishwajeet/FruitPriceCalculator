package com.fruit.calc.serviceimpl;

import java.math.BigDecimal;
import java.util.Optional;

import com.fruit.calc.exception.FruitPriceCalcException;
import com.fruit.calc.model.Basket;
import com.fruit.calc.service.BasketPriceService;
import com.fruit.calc.service.ItemPriceService;


public class BasketPriceServiceImpl implements BasketPriceService
{
	private ItemPriceService itemPrice;
	
	public BasketPriceServiceImpl(ItemPriceService itemPricer) {
		this.itemPrice = itemPricer;
	}

	@Override
	public BigDecimal basketPrice(Basket basket) throws FruitPriceCalcException {
			
		Optional<BigDecimal> result = basket.groupQuantitiesByItem().stream()
		.map(item ->  itemPrice.priceItem(item.getItemId(), item.getQuantity()))
		.reduce(Optional.of(new BigDecimal(0)), (sum, p) -> sum(sum,p),	 (sum, sum2) -> sum(sum,sum2));
		
		if(result.isPresent()){
			return result.get();
		}else
		{
			throw new FruitPriceCalcException("Unable to Calculate basket value");
		}
		
	}
	
	 private static Optional<BigDecimal> sum(Optional<BigDecimal> a, Optional<BigDecimal> b){
			
		return a.isPresent() &&b.isPresent() ? Optional.of(a.get().add(b.get())) : Optional.empty();
			
	}
	
}