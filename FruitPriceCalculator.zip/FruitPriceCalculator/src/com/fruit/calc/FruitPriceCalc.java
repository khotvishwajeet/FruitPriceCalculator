package com.fruit.calc;

import com.fruit.calc.constant.FruitPriceConstant;
import com.fruit.calc.exception.FruitPriceCalcException;
import com.fruit.calc.model.Basket;
import com.fruit.calc.service.BasketPriceService;
import com.fruit.calc.serviceimpl.BasketPriceServiceImpl;
import com.fruit.calc.serviceimpl.ItemPriceServiceImpl;
import com.fruit.calc.service.PriceListService;
import com.fruit.calc.serviceimpl.PriceListServiceImpl;


public class FruitPriceCalc
{
    public static void main( String[] args )
    {
		  PriceListService prices = new PriceListServiceImpl(FruitPriceConstant.FRUIT_PRICES);
		  BasketPriceService service = new BasketPriceServiceImpl(new ItemPriceServiceImpl(prices));
        
        try {

            Basket basket = new Basket(args);
            System.out.println("Total Cost Of Fruit Basket Is : " +service.basketPrice(basket)+" Rs");

        } catch(FruitPriceCalcException exc)
        {
        	exc.printStackTrace();
        }

        		
    }
}