package com.fruit.calc.service;

import java.util.Collection;

import com.fruit.calc.model.FruitPrice;


public interface PriceListService
{

	Collection<FruitPrice> getPricesForItem(String itemId);
}
