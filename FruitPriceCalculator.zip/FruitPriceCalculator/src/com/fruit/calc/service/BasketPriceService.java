package com.fruit.calc.service;

import java.math.BigDecimal;

import com.fruit.calc.exception.FruitPriceCalcException;
import com.fruit.calc.model.Basket;



public interface BasketPriceService {
	
	/**
	 * @param basket Basket Price
	 * @return basket Total Price
	 * @throws FruitPriceCalcException items not present
	 */
	BigDecimal basketPrice(Basket basket) throws FruitPriceCalcException;

}
