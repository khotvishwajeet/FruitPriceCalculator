package com.fruit.calc.service;

import java.math.BigDecimal;
import java.util.Optional;

public interface ItemPriceService
{
	Optional<BigDecimal> priceItem(String itemId, int quantity);
}
