package com.fruit.calc.exception;

/**
 * Custom FruitPriceCalcException - exception
 *
 */
public class FruitPriceCalcException extends Exception
{
	
	private static final long serialVersionUID = 1L;

	public FruitPriceCalcException(String message)
	{
		super(message);
	}
}
