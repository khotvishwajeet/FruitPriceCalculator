package com.fruit.calc.model;

import java.math.BigDecimal;


public class FruitPrice {
	
	private String itemId;
	private BigDecimal price;
	private Integer quantity;
	private BigDecimal pricePerUnit;
	
	public FruitPrice(String id, BigDecimal price, Integer quantity) {
		this.itemId=id;
		this.price = price;
		this.quantity = quantity;
		this.pricePerUnit = price.divide(new BigDecimal(quantity));
	}
	
	public String getItemId() {
		return itemId;
	}

	public BigDecimal getPrice() {
		return price;
	}
	
	public Integer getQuantity() {
		return quantity;
	}
	
	public BigDecimal getPricePerUnit() {
		return pricePerUnit;
	}
	
}
