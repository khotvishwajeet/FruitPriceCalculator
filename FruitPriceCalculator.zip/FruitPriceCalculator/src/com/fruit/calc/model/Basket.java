package com.fruit.calc.model;

import com.fruit.calc.exception.FruitPriceCalcException;

import java.util.*;
import java.util.stream.Collectors;

public class Basket {

	private List<ItemsInBasket> basketItems = new ArrayList<ItemsInBasket>();

	public Basket() { }


	public Basket(String... items) throws FruitPriceCalcException {
		if (items.length == 0)
			throw new FruitPriceCalcException(
					"Please pass valid Fruit name as argument like Banana Orange Apple Lemon Peache");
		for (String item : items) {
			addToBasket(item);
		}
	}


	/**
	 * Adding fruit inside the basket if present then increases the quantity by 1
	 * @param item
	 */
	public void addToBasket(String item) throws FruitPriceCalcException {
		if (item.isEmpty()) {
			throw new FruitPriceCalcException("Basket is empty");
		} else {
			Optional<ItemsInBasket> items = basketItems.stream().filter(element -> element.itemId.equals(item)).findAny();

			if (items.isPresent()) {
				items.get().quantity += 1;
			} else {
				basketItems.add(new ItemsInBasket(item, 1));
			}
		}

	}

	public Integer count(String item) {
		return basketItems
				.stream()
				.filter(e -> e.itemId.equals(item))
				.reduce(0, (sum, p) -> sum += p.quantity,
						(sum1, sum2) -> sum1 + sum2);

	}

	/**
	 *
	 * @return Collection<ItemsInBasket> items inside basket by name
	 */
	public Collection<ItemsInBasket> groupQuantitiesByItem() {
		Map<String,List<ItemsInBasket>> quantitiesPerProduct = basketItems.stream().collect(
				Collectors.groupingBy(p -> p.getItemId()));
		
		return quantitiesPerProduct
				.entrySet()
				.stream()
				.map(e-> new ItemsInBasket((String)e.getKey(), e.getValue().stream().reduce(0, (sum, p) -> sum += p.quantity,
						(sum1, sum2) -> sum1 + sum2))).collect(Collectors.toList());
		
	}

	public class ItemsInBasket {
		private String itemId;
		private Integer quantity;

		private ItemsInBasket(String itemId, Integer quantity) {
			this.itemId = itemId;
			this.quantity = quantity;
		}

		public String getItemId() {
			return itemId;
		}

		public Integer getQuantity() {
			return quantity;
		}


	}

}
