package com.fruit.calc.constant;

import com.fruit.calc.model.FruitPrice;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;

public class FruitPriceConstant
{
    /**
     * Constant For Fruit Prices per quantity
     */
    public static final Collection<FruitPrice> FRUIT_PRICES =
        Arrays.asList( new FruitPrice("Banana",new BigDecimal(20),1),
                       new FruitPrice("Orange",new BigDecimal(30),1),
                       new FruitPrice("Apple",new BigDecimal(40),1),
                       new FruitPrice("Lemon",new BigDecimal(10),1),
                       new FruitPrice("Peache",new BigDecimal(50),1) );
}
