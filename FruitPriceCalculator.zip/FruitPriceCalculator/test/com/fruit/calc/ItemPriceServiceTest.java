package com.fruit.calc;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;

import com.fruit.calc.model.FruitPrice;
import com.fruit.calc.service.ItemPriceService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.fruit.calc.serviceimpl.ItemPriceServiceImpl;
import com.fruit.calc.service.PriceListService;


@RunWith(MockitoJUnitRunner.class)
public class ItemPriceServiceTest {
	
	@Mock
	PriceListService priceList;
	
	@Test
	public void testFruitPrice()
	{
		when(priceList.getPricesForItem("Banana")).thenReturn(Arrays.asList(new FruitPrice("Banana",new BigDecimal(20),1)));

		ItemPriceService pricer = new ItemPriceServiceImpl(priceList);
		
		assertEquals("2 kg Banana 40 rs", new BigDecimal(40),  pricer.priceItem("Banana", 2).get() );
	
	}
	
	@Test
	public void testBestOfferPrice()
	{
		when(priceList.getPricesForItem("Orange")).thenReturn(Arrays.asList(new FruitPrice("Orange",new BigDecimal(30),1), new FruitPrice("Orange",new BigDecimal(30), 2)));
		ItemPriceService pricer = new ItemPriceServiceImpl(priceList);
		assertEquals("3  kg oranges ", new BigDecimal(60),  pricer.priceItem("Orange", 3).get() );
	
	}

	@Test
	public void testPriceNotAvailable()
	{
		when(priceList.getPricesForItem(null)).thenReturn(Collections.emptyList());
		ItemPriceService pricer = new ItemPriceServiceImpl(priceList);
		assertFalse("No price available", pricer.priceItem(null, 1).isPresent() );
	
	}
}
