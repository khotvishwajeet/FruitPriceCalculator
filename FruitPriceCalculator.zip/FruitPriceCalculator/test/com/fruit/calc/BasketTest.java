package com.fruit.calc;

import com.fruit.calc.exception.FruitPriceCalcException;
import org.junit.Assert;
import org.junit.Test;

import com.fruit.calc.model.Basket;


public class BasketTest {

	@Test(expected= FruitPriceCalcException.class)
	public void testBasketEmptyOrNull() throws FruitPriceCalcException {
		Basket basket = new Basket();
		basket.addToBasket("");
	}

	@Test
	public void testBasketIsNotEmpty() throws FruitPriceCalcException {
		Basket basket = new Basket("Orange","Apple", "Mango","Orange");
		Assert.assertTrue(basket.count("Mango") == 1);
		Assert.assertTrue(basket.count("Apple") == 1);
		Assert.assertTrue(basket.count("Orange") == 2);
		Assert.assertTrue(basket.count("Banana") == 0);
	}
}
